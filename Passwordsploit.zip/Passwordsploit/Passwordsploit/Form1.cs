﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using BCrypt.Net; // Ensure you have this package installed

namespace Passwordsploit
{
    public partial class Form1 : Form
    {
        private List<User> users = new List<User>();

        public Form1()
        {
            InitializeComponent();
            // Simulate a user
            users.Add(new User { Username = "admin", PasswordHash = BCrypt.Net.BCrypt.HashPassword("password123") });

            // Create Change Password button
            Button btnChangePassword = new Button
            {
                Text = "Change Password",
                Size = new Size(200, 50), // Set the size to make it bigger
                BackColor = Color.White, // Set the background color to white
                Location = new Point(
                    (ClientSize.Width - 200) / 2, // Center horizontally
                    (ClientSize.Height - 50) / 2 // Center vertically
                )
            };

            btnChangePassword.Click += BtnChangePassword_Click; // Attach the click event
            Controls.Add(btnChangePassword); // Add the button to the form
        }

        private void BtnChangePassword_Click(object sender, EventArgs e)
        {
            string username = "admin"; // In a real app, you'd get this dynamically
            string newPassword = Microsoft.VisualBasic.Interaction.InputBox(
                "Enter your new password:",
                "Change Password",
                "",
                -1,
                -1);

            if (!string.IsNullOrEmpty(newPassword))
            {
                ChangePassword(username, newPassword);
            }
            else
            {
                MessageBox.Show("No password entered. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ChangePassword(string username, string newPassword)
        {
            User user = users.Find(u => u.Username == username);
            if (user != null)
            {
                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);
                MessageBox.Show($"Password for {username} changed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public class User
        {
            public string Username { get; set; }
            public string PasswordHash { get; set; }
        }
    }
}
